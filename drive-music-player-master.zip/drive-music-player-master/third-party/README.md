Third party libraries
=====================

This folder contains the third party libraries used in this application.
